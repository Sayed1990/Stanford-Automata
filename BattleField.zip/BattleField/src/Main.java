import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String args[]){
       // String size="";

        System.out.println("Enter the size of the battelField, Starting position, position of Target, and posiition of all bulletproof");
        Scanner scanner = new Scanner(System.in);
        String inputString = scanner.next();
        String[] spts=inputString.split("\\}"+"\\{");
        for(int i=0;i<spts.length;i++){
            spts[i]=spts[i].replace("{","");
            spts[i]=spts[i].replace("}","");
            System.out.println(spts[i]);
        }
        String[] splitDmension=spts[0].split(",");
        String[] startingPosition=spts[1].split(",");
        String[] targetPosition=spts[2].split(",");
        String[] splitProofs=spts[3].split(",");
        ArrayList<String[]> neList=new ArrayList<>();
        for(int i=0;i<splitProofs.length;i++){
            String[] getSplittedValue=splitProofs[i].split("#");
            neList.add(getSplittedValue);
        }


        BuildFrame blds=new BuildFrame(Integer.parseInt(splitDmension[1]),Integer.parseInt(splitDmension[0]),Integer.parseInt(startingPosition[0]),Integer.parseInt(startingPosition[1]),Integer.parseInt(targetPosition[0]),Integer.parseInt(targetPosition[1]),neList);


       // System.out.println(splitted);

        //{2,2}{2,1}{2,2}{1#1,1#2}
    }
}
