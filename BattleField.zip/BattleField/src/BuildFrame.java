import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class BuildFrame extends JFrame {
    private int width;
        private int height;
    private int startingCoordinateX;
    private int startingCoordinateY;
    private int targetPositionX;
    private int targetPositionY;
    private ArrayList<String[]> neList;
    BuildFrame(int width, int height,int startingCoordinateX,int startingCoordinateY,int targetPositionX,int targetPositionY,ArrayList<String[]> neList){
        width=width;
        height=height;
        startingCoordinateX=startingCoordinateX;
        startingCoordinateY=startingCoordinateY;
        targetPositionX=targetPositionX;
        targetPositionY=targetPositionY;
        neList=neList;
        init(width,height,startingCoordinateX,startingCoordinateY,targetPositionX,targetPositionY,neList);
    }

    private void init(int width, int height, int startingCoordinateX, int startingCoordinateY, int targetPositionX, int targetPositionY, ArrayList<String[]> neList) {
        int total=width*height;

        JButton[][] buttons = new JButton[width][height];

        JFrame frame=new JFrame("Battlefield 1");
        GridLayout experimentLayout = new GridLayout(height,width);
        for(int i=0;i<width;i++){
            for(int j=0;j<height;j++){
                buttons[i][j]= new JButton("");
                frame.add(buttons[i][j]);
            }
        }
        buttons[startingCoordinateY-1][startingCoordinateX-1].setBackground(Color.RED);
        buttons[startingCoordinateY-1][startingCoordinateX-1].setText("Soldier");
        buttons[targetPositionX-1][targetPositionY-1].setBackground(Color.YELLOW);
        buttons[targetPositionX-1][targetPositionY-1].setText("Target");
        for(int ls=0;ls<neList.size();ls++){
            String[] getFromList=neList.get(ls);
            String xposition=getFromList[0];
            String yposition=getFromList[1];
            int x=Integer.parseInt(xposition)-1;
            int y=Integer.parseInt(yposition)-1;
            String getString=buttons[x][y].getText();
            if(getString.equals("")){
                buttons[x][y].setBackground(Color.GRAY);
                buttons[x][y].setText("proofs");
            }else{
                buttons[x][y].setText(getString +" \n and \n proofs");
            }

        }
          Point s=new Point();
        s.setLocation(startingCoordinateX,startingCoordinateY);
        Point s1=new Point();
        s1.setLocation(targetPositionX,targetPositionY);
        double shortest_distance = Double.MAX_VALUE;
        int[] shortest_pair = new int[2];
        for (int i = 0; i < total-1; i++)
        {
            for (int j = i+1; j < total; j++)
            {
                double d = distance(s,s1);
                if (d < shortest_distance)
                {
                    shortest_distance = d;
                    shortest_pair[0] = i+1;
                    shortest_pair[1] = j+1;

                }
            }
        }
        System.out.print( "{"+shortest_pair[1]+"#"+ shortest_pair[0]+"}");
        frame.setLayout(experimentLayout);
        frame.setSize(300,300);
        frame.setVisible(true);


    }
    double distance(Point p1, Point p2)
    {
        return Math.sqrt((p1.x - p2.x)*(p1.x - p2.x) + (p1.y - p2.y)*(p1.y - p2.y));
    }

}
