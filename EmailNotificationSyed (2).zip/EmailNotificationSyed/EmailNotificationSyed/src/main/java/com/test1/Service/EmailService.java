package com.test1.Service;


import com.test1.Model.EmailObject;

public interface EmailService {
    public boolean sendEmailWithAttachment(EmailObject maps);

}
