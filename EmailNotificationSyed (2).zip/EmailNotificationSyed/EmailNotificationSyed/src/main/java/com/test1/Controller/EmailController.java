package com.test1.Controller;
import com.test1.Model.EmailObject;
import com.test1.Service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class EmailController {
@Autowired
private EmailService emailService;

    @RequestMapping(value = "/")
    public String mainpage() {
System.out.print("hehe");
        return "EmailingPage";
    }

        @RequestMapping(value = "sendMail")
    public String emailServicesForLoan(@ModelAttribute EmailObject emailObject)  {
        if(emailService.sendEmailWithAttachment(emailObject)){
            return "Email_Success";
        }
        return "Email_Failure";
    }

    }
