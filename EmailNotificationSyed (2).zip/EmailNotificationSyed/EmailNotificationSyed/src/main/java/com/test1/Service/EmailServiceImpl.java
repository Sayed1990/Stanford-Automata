package com.test1.Service;



import com.test1.Model.EmailObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Service;

import javax.mail.Message;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;


@Service
public class EmailServiceImpl implements EmailService {
    @Autowired
    private JavaMailSender javaMailSender;

    @Override
    public boolean sendEmailWithAttachment(EmailObject obj) {
        boolean status = true;
        MimeMessagePreparator preparator = new MimeMessagePreparator()
        {
            public void prepare(MimeMessage mimeMessage) throws Exception
            {
                /*
                 *MiMeMessageHelper is used as generic because in Email
                 * we can also include Attachment. Although the requirement is only to send notification
                 * it doesn't say about attachment. here we just need to use "MimeMessageHelper.addAttachment method to
                 * Attach Any files like Pdf,JPEG,png, etc etc
                 */
                MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
                mimeMessage.setRecipient(Message.RecipientType.TO, new InternetAddress("izarulazwan90@gmail.com"));
                helper.setFrom(new InternetAddress("ambankTestingbySyed@gmail.com"));
                helper.setSubject(obj.getSubject());
                helper.setText(obj.getMessage());
            }
        };

        try {
            javaMailSender.send(preparator);
        }
        catch (MailException ex) {
            status=false;
            System.err.println(ex.getMessage());
        }
        return status;
    }
}