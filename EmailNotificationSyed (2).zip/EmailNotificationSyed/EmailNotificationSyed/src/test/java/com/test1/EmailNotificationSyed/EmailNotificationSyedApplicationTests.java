package com.test1.EmailNotificationSyed;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailNotificationSyedApplicationTests {

	@Test
	void contextLoads() {
	}

}
