package com.test1.EmailNotificationSyed;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.client.RestTemplate;


@EnableAutoConfiguration
@ComponentScan(basePackages = "com.test1")
@SpringBootApplication
public class EmailNotificationSyedApplication {
	/*@Bean
	RestTemplate restTemplate() {
		return new RestTemplate();
	}*/

	public static void main(String[] args) {

		SpringApplication.run(EmailNotificationSyedApplication.class, args);
	}

}
